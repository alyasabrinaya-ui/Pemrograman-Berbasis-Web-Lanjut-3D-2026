

<?php $__env->startSection('title', 'Daftar Buku'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1>Daftar Buku</h1>
        <p>
            <?php if($keyword !== ''): ?>
                Ditemukan <?php echo e(count($daftarBuku)); ?> buku untuk "<strong><?php echo e($keyword); ?></strong>".
            <?php else: ?>
                Total <?php echo e(count($daftarBuku)); ?> buku tersedia di perpustakaan.
            <?php endif; ?>
        </p>
    </div>

    <form action="<?php echo e(route('buku.index')); ?>" method="GET" class="search-form">
        <input type="text" name="q" value="<?php echo e($keyword); ?>"
               placeholder="Cari judul, penulis, atau kategori..." class="search-input">
        <button type="submit" class="btn btn-primary">Cari</button>
        <?php if($keyword !== ''): ?>
            <a href="<?php echo e(route('buku.index')); ?>" class="btn btn-reset">Reset</a>
        <?php endif; ?>
    </form>

    <?php if(count($daftarBuku) > 0): ?>
        <div class="book-grid">
            <?php $__currentLoopData = $daftarBuku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginala254621cc49975154690d02c2f7a9ddc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala254621cc49975154690d02c2f7a9ddc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kartu-buku','data' => ['buku' => $buku]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kartu-buku'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['buku' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($buku)]); ?>
                     <?php $__env->slot('badge', null, []); ?> <?php echo e($buku['kategori']); ?> <?php $__env->endSlot(); ?>
                    <span class="book-id">ID Buku #<?php echo e($buku['id']); ?></span>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala254621cc49975154690d02c2f7a9ddc)): ?>
<?php $attributes = $__attributesOriginala254621cc49975154690d02c2f7a9ddc; ?>
<?php unset($__attributesOriginala254621cc49975154690d02c2f7a9ddc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala254621cc49975154690d02c2f7a9ddc)): ?>
<?php $component = $__componentOriginala254621cc49975154690d02c2f7a9ddc; ?>
<?php unset($__componentOriginala254621cc49975154690d02c2f7a9ddc); ?>
<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="empty">
            <h2>Yah, bukunya belum ketemu :( </h2>
            <p>Oops! "<strong><?php echo e($keyword); ?></strong>" belum ditemukan.Yuk, temukan cerita lainnya di BACAINAJA!</p>
            <a href="<?php echo e(route('buku.index')); ?>" class="btn btn-primary">Tampilkan Semua Buku</a>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_25044110101\resources\views/buku/index.blade.php ENDPATH**/ ?>