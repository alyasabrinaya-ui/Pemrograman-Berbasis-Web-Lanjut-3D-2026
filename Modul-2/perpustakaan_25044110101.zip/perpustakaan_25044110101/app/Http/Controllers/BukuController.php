<?php

namespace App\Http\Controllers;

use App\Models\Buku;
use Illuminate\Http\Request;

class BukuController extends Controller
{
    
    private function formatBuku(Buku $buku): array
    {
        return [
            'id'           => $buku->id,
            'judul'        => $buku->judul,
            'penulis'      => $buku->penulis,
            'tahun_terbit' => (int) $buku->tahun_terbit,
            'kategori'     => $buku->kategori->nama ?? '-',
        ];
    }

    public function index(Request $request)
    {
        $keyword = trim((string) $request->query('q', ''));

        $query = Buku::with('kategori')->orderBy('id');

        if ($keyword !== '') {
            $query->where(function ($q) use ($keyword) {
                $q->where('judul', 'like', "%{$keyword}%")
                  ->orWhere('penulis', 'like', "%{$keyword}%")
                  ->orWhereHas('kategori', function ($k) use ($keyword) {
                      $k->where('nama', 'like', "%{$keyword}%");
                  });
            });
        }

        $daftarBuku = $query->get()
            ->map(fn (Buku $buku) => $this->formatBuku($buku))
            ->all();

        return view('buku.index', [
            'daftarBuku' => $daftarBuku,
            'keyword'    => $keyword,
        ]);
    }

    public function show($id)
    {
        $record = Buku::with('kategori')->find((int) $id);
        $buku   = $record ? $this->formatBuku($record) : null;

        return response()->view('buku.show', [
            'buku' => $buku,
            'id'   => $id,
        ], $buku ? 200 : 404);
    }
}