<?php

namespace App\Http\Controllers;

use App\Models\Buku;
use App\Models\Kategori;

class BukuController extends Controller
{
    private function formatBuku(Buku $buku): array
    {
        return [
            'id'           => $buku->id,
            'judul'        => $buku->judul,
            'penulis'      => $buku->penulis,
            'tahun_terbit' => (int) $buku->tahun_terbit,
            'kategori'     => $buku->kategori->nama ?? '-',
        ];
    }

    public function index()
    {
        return view('buku.index', [
            'daftarKategori' => Kategori::orderBy('nama')->get(['id', 'nama']),
        ]);
    }

    public function show($id)
    {
        $record = Buku::with('kategori')->find((int) $id);
        $buku   = $record ? $this->formatBuku($record) : null;

        return response()->view('buku.show', [
            'buku' => $buku,
            'id'   => $id,
        ], $buku ? 200 : 404);
    }
}