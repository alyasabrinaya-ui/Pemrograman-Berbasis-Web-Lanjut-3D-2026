<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['buku']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['buku']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<article class="book-card">
    <div class="book-cover cover-<?php echo e($buku['id'] % 5); ?>">
        <?php if(isset($badge)): ?>
            <span class="badge"><?php echo e($badge); ?></span>
        <?php endif; ?>
        <span class="cover-initial"><?php echo e(strtoupper(substr($buku['judul'], 0, 1))); ?></span>
    </div>

    <div class="book-body">
        <h3 class="book-title"><?php echo e($buku['judul']); ?></h3>
        <p class="book-meta">penulis : <?php echo e($buku['penulis']); ?></p>
        <p class="book-meta">tahun : <?php echo e($buku['tahun_terbit']); ?></p>

        <?php if(! $slot->isEmpty()): ?>
            <div class="book-extra"><?php echo e($slot); ?></div>
        <?php endif; ?>

        <a href="<?php echo e(route('buku.show', $buku['id'])); ?>" class="btn btn-primary">Lihat Detail </a>
    </div>
</article><?php /**PATH C:\Users\lenovo\Downloads\laragon\www\perpustakaan_25044110101\resources\views/components/kartu-buku.blade.php ENDPATH**/ ?>