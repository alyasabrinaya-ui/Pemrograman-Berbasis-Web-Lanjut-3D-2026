

<?php $__env->startSection('title', $buku ? $buku['judul'] : 'Buku Tidak Ditemukan'); ?>

<?php $__env->startSection('content'); ?>
    <?php if($buku): ?>
        <a href="<?php echo e(route('buku.index')); ?>" class="back-link">← Kembali ke Daftar Buku</a>

        <div class="detail">
            <div class="detail-cover book-cover cover-<?php echo e($buku['id'] % 5); ?>">
                <span class="badge"><?php echo e($buku['kategori']); ?></span>
                <span class="cover-initial"><?php echo e(strtoupper(substr($buku['judul'], 0, 1))); ?></span>
            </div>

            <div class="detail-info">
                <h1><?php echo e($buku['judul']); ?></h1>
                <dl class="detail-list">
                    <div><dt>ID Buku</dt><dd>#<?php echo e($buku['id']); ?></dd></div>
                    <div><dt>Penulis</dt><dd><?php echo e($buku['penulis']); ?></dd></div>
                    <div><dt>Tahun Terbit</dt><dd><?php echo e($buku['tahun_terbit']); ?></dd></div>
                    <div><dt>Kategori</dt><dd><?php echo e($buku['kategori']); ?></dd></div>
                </dl>
                <a href="<?php echo e(route('buku.index')); ?>" class="btn btn-primary">Lihat Buku Lainnya</a>
            </div>
        </div>
    <?php else: ?>
        <div class="empty">
            <h2>Buku tidak ditemukan</h2>
            <p>Buku dengan ID <strong><?php echo e($id); ?></strong> tidak ada di perpustakaan kami.</p>
            <a href="<?php echo e(route('buku.index')); ?>" class="btn btn-primary">Kembali ke Daftar Buku</a>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_25044110101\resources\views/buku/show.blade.php ENDPATH**/ ?>