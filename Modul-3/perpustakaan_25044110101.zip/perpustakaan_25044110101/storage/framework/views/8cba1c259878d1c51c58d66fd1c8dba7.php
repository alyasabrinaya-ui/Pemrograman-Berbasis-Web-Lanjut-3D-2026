

<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
    <section class="hero">
        <span class="hero-label">WELCOME, BOOKWORM!</span>
        <h1>Temukan buku favoritmu di <em>BACAINAJA</em></h1>
        <p>Jelajahi koleksi buku, temukan bacaan favoritmu,
dan biarkan setiap halaman membawamu ke petualangan baru.</p>
        <a href="<?php echo e(route('buku.index')); ?>" class="btn btn-accent">Lihat Daftar Buku</a>
    </section>

    <section class="features">
        <div class="feature">
            <h3>Mau Baca Apa Hari Ini?</h3>
            <p>Dari yang bikin baper sampai yang bikin pintar, tinggal pilih.</p>
        </div>
        <div class="feature">
            <h3>Kenalan Dulu Sama Bukunya</h3>
            <p>Cek penulis, tahun, dan kategorinya sebelum jatuh cinta.</p>
        </div>
        <div class="feature">
            <h3>Nggak Pakai Lama</h3>
            <p>Buka, scroll, ketemu bacaan favoritmu..</p>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\lenovo\Downloads\laragon\www\perpustakaan_25044110101\resources\views/beranda.blade.php ENDPATH**/ ?>