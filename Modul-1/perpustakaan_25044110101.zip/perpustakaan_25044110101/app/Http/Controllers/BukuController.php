<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BukuController extends Controller
{
 
    private function dataBuku(): array
    {
        return [
            ['id' => 1, 'judul' => 'The Psychology of Money',   'penulis' => 'Morgan Housel',        'tahun_terbit' => 2020, 'kategori' => 'Keuangan'],
            ['id' => 2, 'judul' => 'Bumi Manusia',     'penulis' => 'Pramoedya Ananta Toer', 'tahun_terbit' => 1980, 'kategori' => 'Sastra'],
            ['id' => 3, 'judul' => 'Cantik Itu Luka',   'penulis' => 'Eka Kurniawan',     'tahun_terbit' => 2002, 'kategori' => 'Novel'],
            ['id' => 4, 'judul' => 'Clean Code',       'penulis' => 'Robert C. Martin',      'tahun_terbit' => 2008, 'kategori' => 'Pemrograman'],
            ['id' => 5, 'judul' => 'Berani Tidak Disukai',    'penulis' => 'Ichiro Kishimi & Fumitake Koga',           'tahun_terbit' => 2013, 'kategori' => 'Psikologi'],
            ['id' => 6, 'judul' => 'Laut Bercerita',   'penulis' => 'Leila S. Chudori',      'tahun_terbit' => 2017, 'kategori' => 'Novel'],
            ['id' => 7, 'judul' => 'Nanti Kita Cerita Tentang Hari Ini',   'penulis' => 'Marchella F.P.',      'tahun_terbit' => 2018, 'kategori' => 'Novel'],
            ['id' => 8, 'judul' => 'The Pragmatic Programme',   'penulis' => 'David Thomas & Andrew Hunt',      'tahun_terbit' => 2017, 'kategori' => 'Pemrograman'],
        ];
    }


    public function index(Request $request)
    {
        $keyword = trim((string) $request->query('q', ''));
        $daftarBuku = collect($this->dataBuku());

        if ($keyword !== '') {
            $kata = mb_strtolower($keyword);

            $daftarBuku = $daftarBuku->filter(function ($buku) use ($kata) {
                return str_contains(mb_strtolower($buku['judul']), $kata)
                    || str_contains(mb_strtolower($buku['penulis']), $kata)
                    || str_contains(mb_strtolower($buku['kategori']), $kata);
            });
        }

        return view('buku.index', [
            'daftarBuku' => $daftarBuku->values()->all(),
            'keyword'    => $keyword,
        ]);
    }

 
    public function show($id)
    {
        $buku = collect($this->dataBuku())->firstWhere('id', (int) $id);

        return response()->view('buku.show', [
            'buku' => $buku,
            'id'   => $id,
        ], $buku ? 200 : 404);
    }
}