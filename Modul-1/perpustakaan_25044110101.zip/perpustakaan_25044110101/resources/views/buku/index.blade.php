@extends('layouts.app')

@section('title', 'Daftar Buku')

@section('content')
    <div class="page-head">
        <h1>Daftar Buku</h1>
        <p>
            @if ($keyword !== '')
                Ditemukan {{ count($daftarBuku) }} buku untuk "<strong>{{ $keyword }}</strong>".
            @else
                Total {{ count($daftarBuku) }} buku tersedia di perpustakaan.
            @endif
        </p>
    </div>

    <form action="{{ route('buku.index') }}" method="GET" class="search-form">
        <input type="text" name="q" value="{{ $keyword }}"
               placeholder="Cari judul, penulis, atau kategori..." class="search-input">
        <button type="submit" class="btn btn-primary">Cari</button>
        @if ($keyword !== '')
            <a href="{{ route('buku.index') }}" class="btn btn-reset">Reset</a>
        @endif
    </form>

    @if (count($daftarBuku) > 0)
        <div class="book-grid">
            @foreach ($daftarBuku as $buku)
                <x-kartu-buku :buku="$buku">
                    <x-slot:badge>{{ $buku['kategori'] }}</x-slot:badge>
                    <span class="book-id">ID Buku #{{ $buku['id'] }}</span>
                </x-kartu-buku>
            @endforeach
        </div>
    @else
        <div class="empty">
            <span class="empty-icon">🔍</span>
            <h2>Yah, bukunya belum ketemu :( </h2>
            <p>Oops! "<strong>{{ $keyword }}</strong>" belum ditemukan.Yuk, temukan cerita lainnya di BACAIN!</p>
            <a href="{{ route('buku.index') }}" class="btn btn-primary">Tampilkan Semua Buku</a>
        </div>
    @endif
@endsection