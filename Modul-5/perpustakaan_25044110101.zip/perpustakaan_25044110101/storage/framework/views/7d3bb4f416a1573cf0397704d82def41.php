<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1>Dashboard Admin</h1>
        <p>Selamat datang, <?php echo e(auth()->user()->name); ?>.</p>
    </div>

    <section class="panel">
        <h2>Menu Admin</h2>
        <div class="aksi-menu">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola data buku')): ?><a href="<?php echo e(route('buku.index')); ?>" class="btn btn-primary">Kelola Buku</a><?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola data pengguna')): ?><a href="<?php echo e(route('admin.pengguna.index')); ?>" class="btn btn-primary">Kelola Pengguna & Role</a><?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola peminjaman')): ?><a href="<?php echo e(route('peminjaman.index')); ?>" class="btn btn-primary">Data Peminjaman</a><?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola pengembalian')): ?><a href="<?php echo e(route('pengembalian.index')); ?>" class="btn btn-primary">Data Pengembalian</a><?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat laporan perpustakaan')): ?><a href="<?php echo e(route('laporan.index')); ?>" class="btn btn-primary">Laporan</a><?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_25044110101\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>