<?php $__env->startSection('title', 'Data Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1>Data Peminjaman</h1>
    </div>

    <section class="panel">
        <div class="table-wrap">
            <table class="tabel">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Peminjam</th>
                        <th>Buku</th>
                        <th>Tgl Pinjam</th>
                        <th>Tgl Kembali</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($p->anggota->nama ?? '-'); ?></td>
                            <td><?php echo e($p->buku->judul ?? '-'); ?></td>
                            <td><?php echo e($p->tanggal_pinjam); ?></td>
                            <td><?php echo e($p->tanggal_kembali ?? '-'); ?></td>
                            <td><span class="status status-<?php echo e($p->status); ?>"><?php echo e($p->status); ?></span></td>
                            <td>
                                <?php if($p->status === 'diajukan'): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('memproses persetujuan peminjaman')): ?>
                                        <form method="POST" action="<?php echo e(route('peminjaman.setujui', $p)); ?>">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <button type="submit" class="btn btn-sm btn-primary">Setujui</button>
                                        </form>
                                    <?php endif; ?>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7" class="tabel-info">Belum ada data peminjaman.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_25044110101\resources\views/peminjaman/index.blade.php ENDPATH**/ ?>