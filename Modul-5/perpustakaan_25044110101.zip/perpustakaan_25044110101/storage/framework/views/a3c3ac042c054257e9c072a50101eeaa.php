<?php $__env->startSection('title', 'Kelola Pengguna'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1>Kelola Pengguna</h1>
        <p><a href="<?php echo e(route('admin.pengguna.create')); ?>" class="btn btn-primary">+ Tambah Pengguna</a></p>
    </div>

    <section class="panel">
        <div class="table-wrap">
            <table class="tabel">
                <thead>
                    <tr><th>No</th><th>Nama</th><th>Email</th><th>Role</th><th>Aksi</th></tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($u->name); ?></td>
                            <td><?php echo e($u->email); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola role pengguna')): ?>
                                    <form method="POST" action="<?php echo e(route('admin.pengguna.role', $u)); ?>" class="inline-form">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <select name="role">
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($r); ?>" <?php if($u->hasRole($r)): echo 'selected'; endif; ?>><?php echo e($r); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <button type="submit" class="btn btn-sm btn-reset">Simpan</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('admin.pengguna.edit', $u)); ?>" class="btn btn-sm btn-warning">Ubah</a>
                                <form method="POST" action="<?php echo e(route('admin.pengguna.destroy', $u)); ?>" class="inline-form"
                                      onsubmit="return confirm('Yakin ingin menghapus pengguna ini?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_25044110101\resources\views/admin/pengguna/index.blade.php ENDPATH**/ ?>