<?php $__env->startSection('title', 'Data Pengembalian'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1>Data Pengembalian</h1>
        <p>Buku yang sedang dipinjam.</p>
    </div>

    <section class="panel">
        <div class="table-wrap">
            <table class="tabel">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Peminjam</th>
                        <th>Buku</th>
                        <th>Tgl Pinjam</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($p->anggota->nama ?? '-'); ?></td>
                            <td><?php echo e($p->buku->judul ?? '-'); ?></td>
                            <td><?php echo e($p->tanggal_pinjam); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mencatat pengembalian buku')): ?>
                                    <form method="POST" action="<?php echo e(route('pengembalian.update', $p)); ?>">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="btn btn-sm btn-primary">Catat Pengembalian</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="tabel-info">Tidak ada buku yang sedang dipinjam.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_25044110101\resources\views/pengembalian/index.blade.php ENDPATH**/ ?>