<?php $__env->startSection('title', 'Laporan Perpustakaan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1>Laporan Perpustakaan</h1>
    </div>

    <section class="panel">
        <h2>Jumlah Peminjaman per Status</h2>
        <div class="table-wrap">
            <table class="tabel">
                <thead><tr><th>Status</th><th>Jumlah</th></tr></thead>
                <tbody>
                    <?php $__currentLoopData = ['diajukan', 'dipinjam', 'dikembalikan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr><td><?php echo e($status); ?></td><td><?php echo e($perStatus[$status] ?? 0); ?></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>

    <section class="panel">
        <h2>Jumlah Peminjaman per Buku</h2>
        <div class="table-wrap">
            <table class="tabel">
                <thead><tr><th>Judul</th><th>Dipinjam</th></tr></thead>
                <tbody>
                    <?php $__currentLoopData = $perBuku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr><td><?php echo e($b->judul); ?></td><td><?php echo e($b->peminjamans_count); ?>x</td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_25044110101\resources\views/laporan/index.blade.php ENDPATH**/ ?>