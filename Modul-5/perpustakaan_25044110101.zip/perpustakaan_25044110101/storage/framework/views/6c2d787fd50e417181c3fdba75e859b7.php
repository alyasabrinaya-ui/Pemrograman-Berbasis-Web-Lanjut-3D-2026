<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Beranda'); ?> | Perpustakaan Digital</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>

    <header class="site-header">
        <div class="container header-inner">
            <a href="<?php echo e(route('home')); ?>" class="brand"> BACAIN<span>AJA</span></a>
            <p class="tagline">Your digital library, but make it fun.</p>
        </div>
    </header>

    <nav class="navbar">
        <div class="container nav-inner">
            <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Beranda</a>

            <?php if(auth()->guard()->check()): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('akses dashboard admin')): ?>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">Dashboard Admin</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('akses dashboard petugas')): ?>
                    <a href="<?php echo e(route('petugas.dashboard')); ?>" class="<?php echo e(request()->routeIs('petugas.dashboard') ? 'active' : ''); ?>">Dashboard Petugas</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat daftar buku')): ?>
                    <a href="<?php echo e(route('buku.index')); ?>" class="<?php echo e(request()->routeIs('buku.*') ? 'active' : ''); ?>">Daftar Buku</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola peminjaman')): ?>
                    <a href="<?php echo e(route('peminjaman.index')); ?>" class="<?php echo e(request()->routeIs('peminjaman.*') ? 'active' : ''); ?>">Peminjaman</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola pengembalian')): ?>
                    <a href="<?php echo e(route('pengembalian.index')); ?>" class="<?php echo e(request()->routeIs('pengembalian.*') ? 'active' : ''); ?>">Pengembalian</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat laporan perpustakaan')): ?>
                    <a href="<?php echo e(route('laporan.index')); ?>" class="<?php echo e(request()->routeIs('laporan.*') ? 'active' : ''); ?>">Laporan</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola data pengguna')): ?>
                    <a href="<?php echo e(route('admin.pengguna.index')); ?>" class="<?php echo e(request()->routeIs('admin.pengguna.*') ? 'active' : ''); ?>">Pengguna</a>
                <?php endif; ?>
                <?php if(auth()->user()->anggota): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('melihat riwayat peminjaman sendiri')): ?>
                        <a href="<?php echo e(route('riwayat.show', auth()->user()->anggota)); ?>" class="<?php echo e(request()->routeIs('riwayat.*') ? 'active' : ''); ?>">Riwayat Saya</a>
                    <?php endif; ?>
                <?php endif; ?>

                <div class="nav-right">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat profil sendiri')): ?>
                        <a href="<?php echo e(route('profile.edit')); ?>" class="<?php echo e(request()->routeIs('profile.*') ? 'active' : ''); ?>"><?php echo e(auth()->user()->name); ?></a>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-logout">Logout</button>
                    </form>
                </div>
            <?php else: ?>
                <div class="nav-right">
                    <a href="<?php echo e(route('login')); ?>" class="<?php echo e(request()->routeIs('login') ? 'active' : ''); ?>">Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="<?php echo e(request()->routeIs('register') ? 'active' : ''); ?>">Daftar</a>
                </div>
            <?php endif; ?>
        </div>
    </nav>

    <main>
        <div class="container">
            <?php if(session('sukses')): ?>
                <div class="alert alert-sukses"><?php echo e(session('sukses')); ?></div>
            <?php endif; ?>
            <?php if(session('gagal')): ?>
                <div class="alert alert-gagal"><?php echo e(session('gagal')); ?></div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo e(date('Y')); ?> BACAINAJA</p>
        </div>
    </footer>

</body>
</html><?php /**PATH C:\laragon\www\perpustakaan_25044110101\resources\views/layouts/app.blade.php ENDPATH**/ ?>