<?php $__env->startSection('title', 'Riwayat Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-head">
        <h1>Riwayat Peminjaman</h1>
        <p>Atas nama: <strong><?php echo e($anggota->nama); ?></strong></p>
    </div>

    <section class="panel">
        <div class="table-wrap">
            <table class="tabel">
                <thead>
                    <tr><th>No</th><th>Buku</th><th>Tgl Pinjam</th><th>Tgl Kembali</th><th>Status</th></tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($p->buku->judul ?? '-'); ?></td>
                            <td><?php echo e($p->tanggal_pinjam); ?></td>
                            <td><?php echo e($p->tanggal_kembali ?? '-'); ?></td>
                            <td><span class="status status-<?php echo e($p->status); ?>"><?php echo e($p->status); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="tabel-info">Belum ada riwayat peminjaman.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\perpustakaan_25044110101\resources\views/riwayat/show.blade.php ENDPATH**/ ?>